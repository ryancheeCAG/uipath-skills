// Types for the governance-trace parser (runtime impl in governance.mjs).
// This is the typed contract metric modules import:
//   import { parseGovernanceSpans, countBy } from '@/lib/governance'
//   import type { GovernanceViolation, GovernanceHook } from '@/lib/governance'

export type GovernanceHook =
  | 'BEFORE_AGENT'
  | 'BEFORE_MODEL'
  | 'AFTER_MODEL'
  | 'AFTER_AGENT'
  | (string & {})

/** Raw attributes on a `governance.rule.*` span (all optional — spans vary in richness). */
export interface GovernanceRuleAttributes {
  'governance.rule_id'?: string
  'governance.rule_name'?: string
  'governance.pack_name'?: string
  'governance.hook'?: GovernanceHook
  'governance.matched'?: boolean
  'governance.action'?: string
  'governance.status'?: string
  'governance.detail'?: string
  'governance.agent_name'?: string
  agentName?: string
  agentVersion?: string
}

/** Raw attributes on a `governance.<hook>` summary span. */
export interface GovernanceHookAttributes {
  'governance.hook'?: GovernanceHook
  'governance.total_rules'?: number
  'governance.matched_rules'?: number
  'governance.final_action'?: string
  'governance.enforcement_mode'?: string
  agentName?: string
  agentVersion?: string
}

/** Normalized, UI-ready violation row (one per fired rule). */
export interface GovernanceViolation {
  agentName: string
  agentVersion: string
  ruleId: string
  ruleName: string
  standard: string
  hook: GovernanceHook
  action: string
  status: string
  detail: string
  time: string
  jobKey: string
  traceId: string
}

/**
 * Normalized rule-evaluation row (one per `governance.rule.*` span, PASS + MATCHED).
 * Superset of `GovernanceViolation` with the matched flag + display outcome.
 */
export interface GovernanceRuleEvaluation {
  agentName: string
  agentVersion: string
  ruleId: string
  ruleName: string
  standard: string
  hook: GovernanceHook
  action: string
  status: string
  detail: string
  matched: boolean
  outcome: 'Matched' | 'Pass' | (string & {})
  time: string
  jobKey: string
  traceId: string
}

/** Per-hook rollup from the summary spans. */
export interface GovernanceHookSummary {
  agentName: string
  hook: GovernanceHook
  totalRules: number
  matchedRules: number
  finalAction: string
  enforcementMode: string
  time: string
  jobKey: string
}

/**
 * Minimal structural span the parser needs. `attributes` is a parsed object from
 * `Traces.getById` (`Record<string, unknown>`) or a JSON string from an AgentTraces
 * endpoint — both accepted. Compatible with the SDK's `SpanGetResponse`.
 */
export interface GovernanceSpanLike {
  name?: string | null
  attributes?: string | Record<string, unknown> | null
  startTime?: string | null
  jobKey?: string | null
  traceId?: string | null
}

export function parseGovernanceSpans(
  spans: GovernanceSpanLike[] | null | undefined,
): { violations: GovernanceViolation[]; hookSummaries: GovernanceHookSummary[] }

export function parseRuleEvaluations(
  spans: GovernanceSpanLike[] | null | undefined,
): GovernanceRuleEvaluation[]

export function countBy<T>(rows: T[] | null | undefined, key: (r: T) => string): { name: string; value: number }[]
