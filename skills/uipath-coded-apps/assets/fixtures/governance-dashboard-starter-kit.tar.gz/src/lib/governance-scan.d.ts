// Types for the bounded governance run-scanners (runtime impl in governance-scan.mjs).
// Metric modules import these to fetch + parse the last N agent runs:
//   import { scanViolations, scanEvaluations } from '@/lib/governance-scan'
import type { UiPath } from '@uipath/uipath-typescript/core'
import type { GovernanceViolation, GovernanceRuleEvaluation, GovernanceSpanLike } from './governance'

/** Hard cap on agent runs scanned per call (one Traces.getById per run). */
export const MAX_RUNS: number

/**
 * Scan the last MAX_RUNS agent runs (no per-agent dedup), mapping each run's
 * governance spans to rows via `parse`. Returns the flattened rows.
 */
export function scanRecentRuns<T>(
  sdk: UiPath,
  parse: (spans: GovernanceSpanLike[]) => T[],
): Promise<T[]>

/** Like scanRecentRuns but keeps only the latest run per distinct agent. */
export function scanLatestPerAgent<T>(
  sdk: UiPath,
  parse: (spans: GovernanceSpanLike[]) => T[],
): Promise<T[]>

/** Last-15-runs violations (one row per FIRED rule). */
export function scanViolations(sdk: UiPath): Promise<GovernanceViolation[]>

/** Last-15-runs rule evaluations (every check, PASS + MATCHED). */
export function scanEvaluations(sdk: UiPath): Promise<GovernanceRuleEvaluation[]>
